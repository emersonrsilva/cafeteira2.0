# CAFETEIRA
===================
# COMPOSITE
-------------
Compõe os  sabores de café. 
Vantagem : ao compor os sabores, é possível somar o preço do sabor com base no preço de cada ingrediente. 

# FACTORY
-------------
Para a escolha do sabor de café. 
A FACTORY facilita a instanciação do objeto do sabor de acordo com o ENUM
# OBSERVER
-------------
Observa os estados da cafeteira, se o copo está cheio, se a mistura dos sabores estão prontas 
Assim é possível executar regras quando um certo estado for atingido, como quando o copo estiver cheio parar de encher. 

# Strategy
-------------
Estratégia para os níveis de café no copo. 
Assim ela pode ter a estratégia de copo baixo ou médio sem alterar as regras de negócio 
